# $id:$
# $log:$
echo $1 FAILED | tee -a FAILED
exit -1
